from .base import *

ALLOWED_HOSTS = []
