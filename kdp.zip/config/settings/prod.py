from .base import *

ALLOWED_HOSTS = ['3.39.26.240']
